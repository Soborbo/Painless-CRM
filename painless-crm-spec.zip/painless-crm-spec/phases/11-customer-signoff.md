# Phase 11 — Customer Sign-off & Review

**Status**: Skeleton
**Duration estimate**: 2 weeks
**Prerequisite**: Phase 10 (job execution)

---

## Goal

End-of-job customer signs off the work on the loader's phone. NPS-style survey gates the Google review request — high promoters get the review link, detractors get a private feedback flow that routes to admin instead. Complaint workflow for damages.

## Why this phase matters

Reviews are sales fuel. A 5-star review on Google is worth £200+ in future leads. Equally: a 1-star review tanks conversion. Painless's average is excellent and we want to channel it visibly while giving unhappy customers a private path that resolves the issue before they vent online.

## Deliverables

1. End-of-job sign-off form (PWA, mobile-signed)
2. NPS prompt: "How likely to recommend? 0–10"
3. Branching flow:
   - 9–10 (Promoters): "Would you take 30 seconds to leave a Google review?" with direct link
   - 7–8 (Passives): "Anything we could have done better?" feedback form, no review link
   - 0–6 (Detractors): "Sorry to hear that. What went wrong?" routes to admin for follow-up
4. Follow-up nudge sequence (24h, 72h, 7d) for promoters who haven't left a review
5. Complaint workflow: detractor responses create a `complaints` ticket, admin owns it
6. Damages module: photos + descriptions + claim status + payout amount + insurance claim ref
7. Stats per worker: NPS distribution, review conversion rate

## Key decisions

- **DECISION**: NPS gating legality — UK ASA / Google Business Profile policy permits asking happy customers to review; what's NOT permitted is offering incentives. We gate on satisfaction, not on review quality. **Confirmed acceptable** as long as detractors aren't blocked from leaving a review elsewhere — they're given a private path *first*. This is the industry-standard "review gating" approach used by reputable SaaS (e.g., NiceJob, Birdeye). Document this decision and review with Jay's lawyer if uncertain.
- **DECISION**: One-time vs persistent sign-off link — recommendation: one-time, expires 24h after job complete

## Schema additions

```sql
create table customer_signoffs (
  id uuid primary key,
  company_id uuid not null,
  job_id uuid not null references jobs(id),
  customer_id uuid not null references customers(id),
  signed_at timestamptz default now(),
  signature_data_url text not null,
  satisfaction_score int check (satisfaction_score between 0 and 10),
  feedback_text text,
  ip_address inet,
  user_agent text,
  device_lat numeric(10, 7),
  device_lng numeric(10, 7),
  collected_by_worker_id uuid references workers(id)
);

create table review_requests (
  id uuid primary key,
  company_id uuid not null,
  signoff_id uuid not null references customer_signoffs(id),
  customer_id uuid not null references customers(id),
  channel text check (channel in ('email', 'sms', 'whatsapp')),
  sent_at timestamptz default now(),
  clicked_at timestamptz,
  review_left_at timestamptz,
  review_url text,
  nudge_count int default 0,
  status text check (status in ('pending', 'clicked', 'reviewed', 'expired'))
);

create table complaints (
  id uuid primary key,
  company_id uuid not null,
  job_id uuid not null references jobs(id),
  customer_id uuid not null references customers(id),
  source text check (source in ('signoff_detractor', 'signoff_passive', 'email', 'phone', 'other')),
  description text not null,
  severity text check (severity in ('low', 'medium', 'high', 'critical')),
  status text check (status in ('new', 'investigating', 'resolved', 'escalated')),
  assigned_to_id uuid references users(id),
  resolution_notes text,
  resolved_at timestamptz,
  created_at timestamptz default now()
);

create table damage_claims (
  id uuid primary key,
  company_id uuid not null,
  job_id uuid not null references jobs(id),
  reported_by_worker_id uuid references workers(id),
  reported_by_customer boolean default false,
  description text not null,
  estimated_value_pence int,
  insurance_claim_ref text,
  payout_pence int,
  status text check (status in ('reported', 'investigating', 'agreed', 'paid', 'denied')),
  photos jsonb default '[]',  -- photo IDs from photos table
  created_at timestamptz default now(),
  resolved_at timestamptz
);
```

## Sign-off flow (loader's PWA)

1. Loader taps "End job & get sign-off" → creates one-time URL, opens on customer's phone
2. Customer sees: summary of work done, total hours, any complications noted
3. Customer signs (canvas signature)
4. NPS slider (0–10 with emoji)
5. Branch:
   - **9–10**: Thank you + "Help others find us" + Google review link (deep-link to leave review)
   - **7–8**: Thank you + "What could we improve?" textarea
   - **0–6**: "Sorry to hear that — would you tell us what went wrong?" textarea, escalates to admin

Sign-off completes the job server-side: stage transitions to `completed`, notification to admin, automation triggers (Phase 13: send invoice).

## Nudge sequence (promoters only)

- T+24h: SMS "Thanks for using Painless! Quick favour — would you leave a Google review? [link]"
- T+72h: Email same ask
- T+7d: One last gentle reminder, then stop

If `review_left_at` populates (detected via Google Places API check or referrer of incoming Google traffic), nudges stop.

## Complaint workflow

Detractor or passive feedback creates a `complaints` row. Admin sees in dashboard, assigns to user, tracks resolution. SLA: critical = 1h, high = 4h, medium = 24h, low = 72h.

## Acceptance criteria

- [ ] Loader generates sign-off link, customer signs on phone
- [ ] Promoter (9–10) sees Google review link
- [ ] Detractor (0–6) sees private feedback form, complaint ticket created
- [ ] Passive (7–8) sees feedback form, no review link, no complaint ticket
- [ ] Nudge SMS sent at 24h to promoter who didn't leave review
- [ ] Damage claim created with photos, status updates, insurance ref
- [ ] NPS dashboard widget shows current month's distribution

## Out of scope

- Public review aggregation widget on painlessremovals.com (post-v1; reviews remain on Google)
- Auto-replies to Google reviews (post-v1)
