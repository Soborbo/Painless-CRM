# Painless CRM — Build Spec Package (v2)

**Owner:** Soborbo Ltd · Laszlo
**Client:** Painless Removals (Bristol, est. 1978) · Jay Newton
**Purpose:** Custom operations CRM to replace iMVE, integrated with `painlessremovals.com`
**Build method:** Solo + Claude Code (vibe coded)
**Realistic timeline:** 14–21 months across three releases (v0.1 / v0.2 / v0.3 — see scope split below)
**Stack:** Next.js 16.2 · React 19.2 · Supabase Pro · Cloudflare Workers · TypeScript · Tailwind v4

> **Spec version 2.** Replaces v1 in response to external technical review. Critical fixes: schema bug sweep (company_id, audit trigger, stage enum, payment_allocations, integration_credentials), webhook hardening, review gating removed (Google ToS), iOS PWA foreground sync mandated, scope split into v0.1/v0.2/v0.3. Backups of v1 are at `references-v1/`, `phases-v1/`, `MASTER.v1.md`, `INDEX.v1.md`, `CLAUDE.v1.md`.

---

## How to read this package

Read in this order:

1. **`MASTER.md`** — architecture overview, stack, domain model, multi-tenancy contract, 8 user roles, scope split into v0.1/v0.2/v0.3, build doctrine.
2. **`DECISIONS.md`** — chronological ADR log. The "why" for every architectural choice. Read after MASTER, before phase docs.
3. **`STATE_MACHINE.md`** — canonical job lifecycle. Stages, transitions, required fields, automation hooks. The single source of truth — SQL enum and UI both derive from this.
4. **`SECURITY_MODEL.md`** — threat model, multi-tenant isolation contract, webhook hardening, PII contract, key management.
5. **`INTEGRATION_CONTRACTS.md`** — per-provider contracts (painlessremovals webhooks, Xero, GoCardless, Google Ads, Meta, Resend, Tamar, Liveswitch, Anthropic).
6. **`CLAUDE.md`** — Claude Code working agreement. Drop into project root.
7. **`phases/00-foundation.md`** — start here. The smoke-test gate that decides whether Cloudflare deployment is viable. **Do not start phase 01 until phase 00 acceptance criteria pass.**
8. Each subsequent phase, in order, scoped to the appropriate version (v0.1 / v0.2 / v0.3). **Sequential, not parallel.**
9. **`references/`** — pattern library. Open when a phase says "see references/X". Don't read top-to-bottom.

---

## Package contents

```
painless-crm-spec/
├── INDEX.md                          ← you are here
├── MASTER.md                         ← architecture + scope-split + phase index
├── CLAUDE.md                         ← drop into project root
├── DECISIONS.md                      ← ADR log (15 ADRs, OD-1 to OD-6 open)
├── STATE_MACHINE.md                  ← canonical job lifecycle
├── SECURITY_MODEL.md                 ← threats, RLS contract, webhook hardening, PII
├── INTEGRATION_CONTRACTS.md          ← per-provider integration spec
├── ERROR_HANDLING.md                 ← error code namespace, retry policy, Sentry rules
├── MIGRATION_MAPPING.md              ← iMVE → painless-crm field mapping (skeleton)
├── DATA_DICTIONARY.md                ← every field with explanation (skeleton)
├── phases/
│   ├── 00-foundation.md              ← Cloudflare smoke test (v0.1 GATE)
│   ├── 01-auth-multitenant.md        ← v0.1
│   ├── 02-database-schema.md         ← v0.1
│   ├── 03-customer-360.md            ← v0.1
│   ├── 04-jobs-pipeline.md           ← v0.1 (uses STATE_MACHINE.md as canonical)
│   ├── 05-pricing-engine.md          ← v0.1 (calculator webhook + KV)
│   ├── 06-quote-builder.md           ← v0.1 (PDF, public acceptance)
│   ├── 07-capacity-pricing.md        ← v0.2 (dynamic margin, capacity calendar)
│   ├── 08-resource-management.md     ← v0.2 (vehicles, storage, workers, rota)
│   ├── 09-worker-pwa.md              ← v0.2 (iOS-aware foreground sync — v2 mandate)
│   ├── 10-job-execution.md           ← v0.2 (job sheets, surveys)
│   ├── 11-customer-signoff.md        ← v0.2 (universal review request — v2 fix)
│   ├── 12-invoicing-payments.md      ← v0.2 (Xero) + v0.3 (GoCardless DD, dunning)
│   ├── 13-communications-hub.md      ← v0.3 (Email + SMS + WhatsApp + Tamar)
│   ├── 14-reporting-analytics.md     ← v0.3 (dashboards, attribution, ad sync)
│   ├── 15-notifications-collab.md    ← v0.3 (push, in-app, @mentions)
│   ├── 16-affiliate-quality.md       ← v0.3 (affiliate codes, insurance/damages)
│   └── 17-migration-golive.md        ← v0.3 (iMVE import, staged rollout)
├── references/
│   ├── schema.sql                    ← full annotated Postgres schema (v2)
│   ├── types.ts                      ← TypeScript domain types
│   ├── rls-patterns.md               ← RLS policy templates
│   ├── kv-broadcast.md               ← Cloudflare KV write/read pattern
│   ├── audit-log.md                  ← Postgres audit trigger pattern
│   └── webhook-pattern.md            ← inbound webhook handler v2 (hardened)
├── TEST_FIXTURES/
│   ├── jay-v42-pricing-scenarios.json   ← 17 Jay scenarios for pricing CI
│   └── webhook-fixtures.json            ← signature/timestamp test cases
├── references-v1/                    ← v1 backup (do not edit)
├── phases-v1/                        ← v1 backup (do not edit)
├── MASTER.v1.md / INDEX.v1.md / CLAUDE.v1.md  ← v1 backups
```

---

## Scope split: v0.1 / v0.2 / v0.3

The full 17-phase build is 14–21 months solo. To get value to Jay quickly, the build is split into three releasable versions. Each is internally complete and deployable.

### v0.1 — Internal CRM (months 1–9)
**Goal:** Painless internal go-live. Replace iMVE for lead capture, kanban, quoting, and basic reporting. Manual invoicing (still in Xero, not yet synced from CRM). Office-only — no PWA, no automation engine, no DD.

Phases included:
- 00 Foundation (smoke-test gate)
- 01 Auth + RLS + multi-tenant
- 02 Database schema
- 03 Customer 360
- 04 Jobs pipeline (kanban, full STATE_MACHINE)
- 05 Pricing engine + calculator webhook
- 06 Quote builder + public acceptance
- (light) basic email via Resend
- (light) basic reporting v1

Acceptance: Jay's whole sales team uses the system for lead-to-quote-to-acceptance. Calculator quotes flow into the CRM via webhooks. Manual invoice status updates work. iMVE remains source of truth for historical jobs (read-only).

### v0.2 — Operations + Xero (months 10–15)
**Goal:** Worker PWA, automated invoicing, dynamic pricing, capacity calendar.

Phases included:
- 07 Capacity + pricing
- 08 Resource management (vehicles, storage, workers, rota)
- 09 Worker PWA (iOS-aware sync)
- 10 Job execution (sheets, video surveys)
- 11 Customer sign-off + universal review request
- 12 Invoicing-payments (Xero portion)

Acceptance: Crews work fully from the PWA, invoices flow to Xero, customers self-serve sign-off and reviews.

### v0.3 — Full automation + migration (months 16–21)
**Goal:** GoCardless DD, WhatsApp, full automation engine, affiliate portal, iMVE migration, advanced reporting.

Phases included:
- 12 (cont.) GoCardless DD + dunning
- 13 Communications hub (WhatsApp, SMS, Tamar)
- 14 Reporting v2 + ad attribution
- 15 Notifications + collaboration
- 16 Affiliate + quality
- 17 iMVE migration + final cutover

Acceptance: iMVE is fully retired. Painless runs entirely on the new CRM.

---

## Build doctrine (one-page summary)

1. **Sequential phases, not parallel.** Each phase has acceptance criteria. Don't start the next until current passes.
2. **Phase 00 is a hard gate.** If Cloudflare Workers can't run Supabase Realtime, PDF generation, image processing, or Excel export reliably, switch CRM to Vercel before phase 01.
3. **Multi-tenant from day 1.** `company_id UUID NOT NULL` everywhere. RLS via `current_user_company_id()`. Painless = `'00000000-0000-0000-0000-000000000001'`. (See SECURITY_MODEL.md §2.)
4. **No data is ever hard-deleted.** Soft delete via `deleted_at`. RLS hides deleted rows.
5. **All mutations audited.** Defensive trigger on every business table — see ADR-007 and `references/audit-log.md`.
6. **Pricing engine is single source of truth.** CRM master, calculator reads from KV. Quote freeze via `pricing_versions` snapshot (ADR-005).
7. **Jay's 17 v4.2 fixtures are sacred.** Any pricing change must keep all 17 within ±15%. Tests in `TEST_FIXTURES/jay-v42-pricing-scenarios.json`, run in both repos.
8. **Workers are contractors.** No PAYE, no HMRC RTI (ADR-006).
9. **PII strict scrub** in Sentry, logs, AI calls. See SECURITY_MODEL.md §6.
10. **Quote freeze.** Once issued, price holds for `quote_validity_days` regardless of config changes.
11. **Job-centric domain.** Jobs table is the spine. "Lead" = `jobs.stage='lead'` (ADR-001).
12. **Vendor-neutral core.** Cloudflare-specific code in adapter modules. CRM portable to Vercel if smoke-test forces switch.
13. **STATE_MACHINE.md is law.** SQL enum, kanban, automation, reporting all derive from it. CI compliance test enforces (ADR-013).
14. **Webhook handler v2 from day 1.** All inbound webhooks use the 5-gate hardened pattern (ADR-014).
15. **Universal review request, no gating.** Every paid customer gets the same email containing both review + complaint links (ADR-010).
16. **iOS PWA: foreground sync mandatory.** No background-sync-only flows on iOS (ADR-011).
17. **Discipline: every architectural change creates an ADR.** No silent decisions.

---

## Stack pin (lock these versions)

```json
{
  "dependencies": {
    "next": "16.2.0",
    "react": "19.2.0",
    "react-dom": "19.2.0",
    "@supabase/supabase-js": "^2.99.0",
    "@supabase/ssr": "^0.9.0",
    "@opennextjs/cloudflare": "^1.0.0",
    "tailwindcss": "^4.0.0",
    "zod": "^3.23.0",
    "next-intl": "^3.20.0"
  }
}
```

Patch updates only (`^x.y.z`). Major/minor upgrades are deliberate decisions on a quiet day with full regression test.

---

## Open decisions (OD-1 to OD-6, see DECISIONS.md)

These are flagged in the relevant phase docs. None blocks v0.1 phase 00–06:

- **OD-1 (Phase 13, v0.3):** Tamar Telecom — Partner API access vs email parsing fallback
- **OD-2 (Phase 09, v0.2):** Vehicle check form — keep public on painlessremovals or PWA only? (Rec: PWA only)
- **OD-3 (Phase 10, v0.2):** Liveswitch scope — upload-only or full live SDK
- **OD-4 (Phase 17, v0.3):** iMVE migration scope — full historical vs 12 months active (Rec: 12 months active + read-only archive)
- **OD-5 (Phase 01, v0.2):** 2FA for admin from v0.1 or v0.2 (Rec: v0.2 mandatory, v0.1 optional)
- **OD-6 (Phase 09, v0.2):** Worker PWA session length — 7 days vs 30 days (Rec: 7 days)

---

## Costs (steady state)

| Item | Cost/month |
|------|------------|
| Supabase Pro | $25 |
| Cloudflare Workers Paid | already paid |
| Resend | $20 |
| Sentry | $26 |
| Anthropic API (Haiku duplicate detection) | ~$2 |
| WhatsApp Business API (Meta direct, post-v0.3) | ~$10 (low volume) |
| **Total** | **~$83/mo** |

One-off: Tamar Partner API setup if approved (TBD), Liveswitch (already owned), GoCardless setup fee (£0, pay-as-you-go).

---

## What this spec is NOT

- It's not a working codebase. It's a build plan that Claude Code uses phase by phase.
- It's not a fixed-price contract. Phases will reveal unknowns; re-scoping is expected.
- It's not a SaaS spec. Multi-tenant infra is in place day 1, but white-labelling is post-v0.3.
- It's not a competitor to enterprise CRMs. It's deliberately Painless-shaped, with knobs future tenants can re-tune.

---

## Changelog

**v2** — Schema bug sweep, webhook hardening, review gating removed, iOS PWA mandates, scope split into v0.1/v0.2/v0.3. New top-level docs: STATE_MACHINE, SECURITY_MODEL, DECISIONS, INTEGRATION_CONTRACTS, ERROR_HANDLING, MIGRATION_MAPPING, DATA_DICTIONARY.

**v1** — Initial 18-phase plan, monolithic timeline.
