# Webhook Pattern (Inbound)

This document defines the canonical inbound webhook handler in painless-crm. All Phase 5 webhooks (from painlessremovals) follow this. Phase 12 webhooks from GoCardless and Phase 13 from Resend / Meta also use this pattern with provider-specific signature verification.

## Why a single pattern

Every inbound webhook needs the same five things:
1. **Signature verification** — only legitimate senders accepted
2. **Idempotent processing** — duplicate sends are no-ops
3. **Schema validation** — payload shape enforced via Zod
4. **Activity logging** — debug-friendly traces
5. **Error responses** — sender knows whether to retry

Implementing each from scratch is how bugs creep in. We use a shared handler shell.

---

## The shared shell

```ts
// src/lib/webhooks/handler.ts

import { NextRequest, NextResponse } from 'next/server';
import { z, ZodSchema } from 'zod';
import { getAdminClient } from '@/lib/supabase/admin';
import * as Sentry from '@sentry/nextjs';

interface WebhookHandlerOptions<T> {
  source: string;                       // 'painlessremovals', 'gocardless', 'resend', etc.
  schema: ZodSchema<T>;
  verifySignature: (rawBody: string, headers: Headers) => Promise<boolean> | boolean;
  extractEventId: (payload: T) => string;
  process: (payload: T, ctx: { admin: ReturnType<typeof getAdminClient> }) => Promise<{ ok: true } | { ok: false; reason: string }>;
}

export function createWebhookHandler<T>(opts: WebhookHandlerOptions<T>) {
  return async (req: NextRequest) => {
    const startedAt = Date.now();
    let rawBody = '';
    try {
      rawBody = await req.text();

      // 1. Signature verification
      const valid = await opts.verifySignature(rawBody, req.headers);
      if (!valid) {
        return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
      }

      // 2. Schema validation
      let payload: T;
      try {
        const parsed = JSON.parse(rawBody);
        payload = opts.schema.parse(parsed);
      } catch (err) {
        return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
      }

      // 3. Idempotency check
      const eventId = opts.extractEventId(payload);
      const admin = getAdminClient();

      const { data: existing } = await admin
        .from('webhook_events')
        .select('id, result')
        .eq('source', opts.source)
        .eq('event_id', eventId)
        .maybeSingle();

      if (existing) {
        return NextResponse.json({ ok: true, duplicate: true, event_id: eventId });
      }

      // 4. Insert in webhook_events (claims the event_id)
      const { error: insertErr } = await admin
        .from('webhook_events')
        .insert({
          source: opts.source,
          event_id: eventId,
          event_type: opts.source + ':' + (payload as any).type ?? 'unknown',
          payload: payload as any,
        });

      if (insertErr) {
        if (insertErr.code === '23505') {
          // Concurrent duplicate — race condition where two handlers tried to claim the same event_id
          return NextResponse.json({ ok: true, duplicate: true, event_id: eventId });
        }
        throw insertErr;
      }

      // 5. Process
      const result = await opts.process(payload, { admin });

      // 6. Mark processed
      await admin
        .from('webhook_events')
        .update({
          processed_at: new Date().toISOString(),
          result: result.ok ? 'success' : 'failed',
          error_message: result.ok ? null : result.reason,
        })
        .eq('source', opts.source)
        .eq('event_id', eventId);

      // 7. Respond
      const elapsed = Date.now() - startedAt;
      return NextResponse.json({ ok: result.ok, event_id: eventId, elapsed_ms: elapsed });
    } catch (err) {
      Sentry.captureException(err, {
        extra: { source: opts.source, raw_body_length: rawBody.length },
      });
      return NextResponse.json({ error: 'Server error' }, { status: 500 });
    }
  };
}
```

---

## Per-source signature verification

### painlessremovals (HMAC-SHA256)

```ts
// src/lib/webhooks/sources/painlessremovals.ts

import { createHmac, timingSafeEqual } from 'crypto';

export function verifyPainlessRemovalsHMAC(rawBody: string, headers: Headers): boolean {
  const signature = headers.get('X-Webhook-Signature');
  if (!signature) return false;

  const secret = process.env.CRM_WEBHOOK_SECRET!;
  const expected = createHmac('sha256', secret).update(rawBody).digest('hex');

  // timingSafeEqual prevents timing attacks
  const sigBuf = Buffer.from(signature, 'hex');
  const expBuf = Buffer.from(expected, 'hex');
  if (sigBuf.length !== expBuf.length) return false;
  return timingSafeEqual(sigBuf, expBuf);
}
```

Painlessremovals side (sender):

```ts
// painlessremovals/src/lib/integrations/crm.ts

export async function sendCrmWebhook(eventType: string, payload: any) {
  const body = JSON.stringify(payload);
  const signature = createHmac('sha256', env.CRM_WEBHOOK_SECRET).update(body).digest('hex');

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(`${env.CRM_BASE_URL}/api/webhooks/${eventType}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Signature': signature,
        },
        body,
      });
      if (res.ok) return await res.json();
      if (res.status >= 500) {
        await sleep(attempt * 1000);
        continue;
      }
      // 4xx — don't retry, log and move on
      console.error(`CRM webhook ${eventType} returned ${res.status}`);
      return null;
    } catch (err) {
      if (attempt === 3) {
        console.error(`CRM webhook ${eventType} failed after 3 attempts`, err);
        return null;
      }
      await sleep(attempt * 1000);
    }
  }
  return null;
}
```

The sender uses `Promise.allSettled([...mirrors, sendCrmWebhook(...)])` so a CRM outage never blocks user-facing flows.

### GoCardless (Webhook-Signature header)

```ts
// src/lib/webhooks/sources/gocardless.ts

import { createHmac, timingSafeEqual } from 'crypto';

export function verifyGoCardlessSignature(rawBody: string, headers: Headers): boolean {
  const signature = headers.get('Webhook-Signature');
  if (!signature) return false;

  const secret = process.env.GOCARDLESS_WEBHOOK_SECRET!;
  const expected = createHmac('sha256', secret).update(rawBody).digest('hex');

  const sigBuf = Buffer.from(signature, 'hex');
  const expBuf = Buffer.from(expected, 'hex');
  if (sigBuf.length !== expBuf.length) return false;
  return timingSafeEqual(sigBuf, expBuf);
}
```

### Resend (Svix-style signature)

```ts
// src/lib/webhooks/sources/resend.ts

import { Webhook } from 'svix';

export function verifyResendSignature(rawBody: string, headers: Headers): boolean {
  try {
    const wh = new Webhook(process.env.RESEND_WEBHOOK_SECRET!);
    const headerObj = {
      'svix-id': headers.get('svix-id'),
      'svix-timestamp': headers.get('svix-timestamp'),
      'svix-signature': headers.get('svix-signature'),
    };
    wh.verify(rawBody, headerObj as Record<string, string>);
    return true;
  } catch {
    return false;
  }
}
```

---

## Example: complete handler for incoming quote

```ts
// src/app/api/webhooks/quote/route.ts

import { z } from 'zod';
import { createWebhookHandler } from '@/lib/webhooks/handler';
import { verifyPainlessRemovalsHMAC } from '@/lib/webhooks/sources/painlessremovals';
import { ingestQuote } from '@/lib/jobs/ingest';

const quoteEventSchema = z.object({
  event_id: z.string(),
  source: z.string(),
  customer: z.object({
    full_name: z.string(),
    email: z.string().email(),
    phone: z.string(),
    postcode: z.string(),
  }),
  addresses: z.object({
    from: z.any(),
    to: z.any(),
  }),
  quote: z.object({
    pricing_version_id: z.string().uuid(),
    size_code: z.string(),
    distance_miles: z.number(),
    complications: z.array(z.string()),
    total_pence: z.number().int(),
    breakdown: z.any(),
  }).optional(),
  attribution: z.any().optional(),
  consent: z.any(),
});

export const POST = createWebhookHandler({
  source: 'painlessremovals',
  schema: quoteEventSchema,
  verifySignature: verifyPainlessRemovalsHMAC,
  extractEventId: (payload) => payload.event_id,
  async process(payload, { admin }) {
    try {
      await ingestQuote(payload, admin);
      return { ok: true };
    } catch (err: any) {
      return { ok: false, reason: err.message };
    }
  },
});
```

---

## Failure handling

If `process()` returns `{ ok: false }`:
- The `webhook_events` row is marked `result: 'failed'` with `error_message`
- The HTTP response returns 200 with `{ ok: false }` (from sender's perspective: we received it, don't retry)
- Sentry captures the underlying error
- An admin alert is triggered if `failed` count exceeds threshold per hour

Why 200 (not 500) on processing failure? If we return 500, the sender retries — but the event_id is already in `webhook_events` so retries are no-ops. We'd just churn requests. Better to acknowledge receipt and surface the failure to admins for manual investigation.

If we want sender retry on a transient failure (e.g., DB temporarily down), we can throw inside `process()` instead of returning `{ ok: false }`. The shell catches and returns 500.

---

## Observability

Every webhook flow logs:
- Receipt timestamp + headers
- Verification result
- Event ID extracted
- Processing duration
- Result (success/duplicate/failed)
- Sentry breadcrumb on each step

Dashboard: `/dashboard/admin/webhooks` shows the last 100 events per source with status, useful during incident debugging.

---

## Webhooks the CRM exposes (Phase 5)

| Path | Source | Purpose |
|---|---|---|
| `POST /api/webhooks/quote` | painlessremovals | Calculator submission, save-quote API |
| `POST /api/webhooks/contact` | painlessremovals | Contact form submission |
| `POST /api/webhooks/callback` | painlessremovals | Callback request |
| `POST /api/webhooks/affiliate` | painlessremovals | Affiliate code lead |
| `POST /api/webhooks/clearance-callback` | painlessremovals | Clearance form |
| `POST /api/webhooks/partner-register` | painlessremovals | Partner self-registration |
| `POST /api/webhooks/gocardless` | GoCardless | Payment events, mandate changes |
| `POST /api/webhooks/resend` | Resend | Email delivered/opened/bounced |
| `POST /api/webhooks/meta-whatsapp` | Meta | WhatsApp inbound messages |
| `POST /api/webhooks/twilio` | Twilio | SMS delivered/inbound |

Each follows this pattern. Source-specific signature verifier + Zod schema + processor function.
