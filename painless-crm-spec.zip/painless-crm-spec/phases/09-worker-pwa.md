# Phase 09 — Worker PWA

**Status**: Skeleton
**Duration estimate**: 4 weeks
**Prerequisite**: Phase 01 (auth, magic links), Phase 08 (rota assignments)

---

## Goal

Mobile-first Progressive Web App for loaders and drivers. Offline-first because Bristol postcodes have signal black spots. Magic-link login (no remembered passwords). Functions: see today's job, clock in with GPS check, complete vehicle check, upload photos, complete end-of-job sheet, get push for new assignments.

## Deliverables

1. PWA manifest, service worker, installable on iOS Safari and Android Chrome
2. Magic-link login flow (no password)
3. Today's jobs view: cards for each assigned job, status (upcoming/in-progress/done)
4. Job detail: addresses, customer name, contact phone (tap to call), notes from sales
5. Clock-in flow: GPS verification — flag if pressed >500m from job address
6. Vehicle pre-check form (digital signature, photo of dashboard)
7. Photo upload: before / during / after / damage, multi-select, offline queue
8. Time entries (start of move, end of load, end of unload, end of job)
9. End-of-job sheet: actual cubic feet, complications encountered, customer satisfaction note
10. Push notifications: new assignment, schedule change, message from admin
11. Offline queue: IndexedDB stores actions, syncs when back online
12. Vehicle check submission appears in admin UI in real time (Supabase Realtime)

## Key decisions

- **DECISION**: Native iOS push or web push only? Web push works on iOS 16.4+. Recommendation: web push — sufficient and avoids App Store.
- **DECISION**: Photo storage — Supabase Storage with size limits, or Cloudflare R2? Recommendation: Supabase Storage in v1 (one provider for everything), migrate to R2 if costs balloon.
- **DECISION**: GPS variance threshold — 500m default, configurable per company in settings.

## Schema additions

```sql
create table time_entries (
  id uuid primary key,
  company_id uuid not null,
  job_id uuid not null references jobs(id),
  worker_id uuid not null references workers(id),
  type text check (type in ('clock_in', 'load_start', 'load_end', 'unload_start', 'unload_end', 'clock_out', 'break_start', 'break_end')),
  occurred_at timestamptz not null,
  gps_lat numeric(10, 7),
  gps_lng numeric(10, 7),
  gps_accuracy_m numeric,
  distance_from_job_address_m numeric,  -- computed at insert
  flagged boolean default false,         -- distance > threshold
  notes text,
  created_at timestamptz default now()
);

create index time_entries_job_idx on time_entries(job_id, occurred_at);
create index time_entries_worker_period_idx on time_entries(worker_id, occurred_at desc);

create table vehicle_checks (
  id uuid primary key,
  company_id uuid not null,
  vehicle_id uuid not null references vehicles(id),
  job_id uuid references jobs(id),
  worker_id uuid not null references workers(id),
  date date not null,
  fuel_level int check (fuel_level between 0 and 100),
  mileage int,
  walk_around_clear boolean,
  defects_noted text,
  dashboard_photo_url text,
  signature_data_url text,
  submitted_at timestamptz default now()
);

create table photos (
  id uuid primary key,
  company_id uuid not null,
  job_id uuid not null references jobs(id),
  uploaded_by_worker_id uuid references workers(id),
  uploaded_by_user_id uuid references users(id),
  category text check (category in ('before', 'during', 'after', 'damage', 'inventory', 'paperwork')),
  url text not null,
  thumbnail_url text,
  notes text,
  taken_at timestamptz,
  uploaded_at timestamptz default now()
);
```

## Pages (PWA, separate route group)

```
src/app/(worker)/
├── layout.tsx (PWA shell, no top nav)
├── login/page.tsx (email → magic link)
├── home/page.tsx (today's jobs)
├── jobs/[id]/
│   ├── page.tsx (job overview)
│   ├── clock-in/page.tsx
│   ├── vehicle-check/page.tsx
│   ├── photos/page.tsx
│   ├── sheet/page.tsx (end-of-job)
│   └── signoff/page.tsx (customer signs, Phase 11)
└── availability/page.tsx (weekly poll, Phase 8)
```

## Offline queue pattern

```ts
// src/app/(worker)/_lib/offline-queue.ts
// IndexedDB-backed queue
// Each action: { id, type, payload, attempts, created_at }
// Sync runs:
//   - on network reconnect
//   - on app foreground
//   - every 60s when online
// Server-side dedup by client-generated UUID (in payload.event_id)
```

Photos upload via background sync API with exponential retry. Hold onto offline-captured photos in IndexedDB Blob storage until sync confirms.

## GPS verification

On clock-in:
1. Get current position (high accuracy, 10s timeout)
2. Geocode job address (cached after first lookup)
3. Compute haversine distance
4. If > threshold (default 500m): show "You don't appear to be at the job site. Continue anyway?" with reason field
5. Store entry with `flagged = true` if user proceeds

Admin alert: if > N flagged clock-ins per worker per week, dashboard surfaces it.

## Acceptance criteria

- [ ] Worker installs PWA on iOS, opens, signs in via magic link
- [ ] Today's jobs render correctly with assigned crew
- [ ] Tap address → opens in Apple/Google Maps
- [ ] Clock-in within 500m of address: success
- [ ] Clock-in 5km from address: warning + flagged record
- [ ] Photos uploaded offline → appear in admin UI within 60s of going online
- [ ] Push notification received for new assignment within 30s
- [ ] Admin sees vehicle check submission in real time
- [ ] End-of-job sheet auto-suggests cubic-feet from quote, worker can adjust

## Out of scope

- Worker-to-worker messaging (post-v1)
- Tip / commission tracking (post-v1)
- Performance leaderboard inside PWA (post-v1)
