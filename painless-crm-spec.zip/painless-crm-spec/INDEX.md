# Painless CRM — Build Spec Package

**Owner:** Soborbo Ltd · Laszlo
**Client:** Painless Removals (Bristol, est. 1978) · Jay Newton
**Purpose:** Custom operations CRM to replace iMVE, integrated with `painlessremovals.com`
**Build method:** Solo + Claude Code (vibe coded), 13–15 months realistic
**Stack:** Next.js 16.2 · React 19.2 · Supabase Pro · Cloudflare Workers · TypeScript · Tailwind v4

---

## How to read this package

Read in this order:

1. **`MASTER.md`** — full architectural overview, stack, domain model, multi-tenancy contract, 8 user roles, 18-phase index, scope exclusions, build doctrine. Single source of truth.
2. **`CLAUDE.md`** — Claude Code working agreement. Coding rules, file structure, DO NOT MODIFY list, multi-tenant rules, i18n, PII handling, git conventions. Drop this into the project root as `CLAUDE.md` so Claude Code auto-loads it.
3. **`phases/00-foundation.md`** — start here. The smoke-test gate that decides whether Cloudflare deployment is viable for this CRM. **Do not start phase 01 until phase 00 acceptance criteria pass.**
4. Each subsequent phase in order. **Sequential, not parallel.** The phases assume earlier phases are complete.
5. **`references/`** — pattern library. Open these when a phase says "see references/X". Don't read top-to-bottom.

---

## Package contents

```
painless-crm-spec/
├── INDEX.md                          ← you are here
├── MASTER.md                         ← architecture + 18-phase index
├── CLAUDE.md                         ← drop into project root
├── phases/
│   ├── 00-foundation.md              ← Next.js + Supabase + Cloudflare smoke test
│   ├── 01-auth-multitenant.md        ← RLS, roles, invitations, audit log trigger
│   ├── 02-database-schema.md         ← all tables, indexes, RPC functions
│   ├── 03-customer-360.md            ← unified B2C/B2B customer card with tabs
│   ├── 04-jobs-pipeline.md           ← kanban, job detail, AI duplicate detection
│   ├── 05-pricing-engine.md          ← v4.2 engine + KV broadcast + webhook (highest leverage)
│   ├── 06-quote-builder.md           ← PDF gen, public acceptance, e-signature
│   ├── 07-capacity-pricing.md        ← public capacity calendar + dynamic margin
│   ├── 08-resource-management.md     ← vehicles, storage, workers, daily rota
│   ├── 09-worker-pwa.md              ← offline-first, GPS clock-in, photo upload
│   ├── 10-job-execution.md           ← job sheets, photo/video, surveys
│   ├── 11-customer-signoff.md        ← mobile sign-off, NPS gate, complaints
│   ├── 12-invoicing-payments.md      ← Xero, GoCardless DD, dunning
│   ├── 13-communications-hub.md      ← Email + SMS + WhatsApp + Tamar parsing
│   ├── 14-reporting-analytics.md     ← dashboards, source attribution, ad sync
│   ├── 15-notifications-collab.md    ← push, in-app, @mentions
│   ├── 16-affiliate-quality.md       ← affiliate codes, insurance/damages
│   └── 17-migration-golive.md        ← iMVE import, staged rollout, fallback
└── references/
    ├── schema.sql                    ← full annotated Postgres schema
    ├── types.ts                      ← TypeScript domain types
    ├── rls-patterns.md               ← RLS policy templates
    ├── kv-broadcast.md               ← Cloudflare KV write/read pattern
    ├── audit-log.md                  ← Postgres audit trigger pattern
    └── webhook-pattern.md            ← inbound webhook handler template
```

---

## Build doctrine (one-page summary)

1. **One phase at a time. No parallelism.** Each phase has acceptance criteria. Don't start the next until the current passes.
2. **Phase 00 is a smoke-test gate.** If Cloudflare Workers can't run Supabase Realtime, PDF generation, image processing, or Excel export reliably, switch CRM to Vercel before phase 01. Don't ignore failures.
3. **Multi-tenant from day 1.** Every table has `company_id UUID NOT NULL`. Every RLS policy uses `current_user_company_id()`. Painless = `'00000000-0000-0000-0000-000000000001'`.
4. **No data is ever hard-deleted.** Soft delete via `deleted_at` only. RLS policies hide deleted rows from default queries.
5. **All mutations are audited.** A Postgres trigger writes to `activity_log` on every INSERT/UPDATE/DELETE. No exceptions for "small" changes.
6. **Pricing engine is one source of truth.** CRM is master, painlessremovals.com calculator reads from KV. Never let the two diverge.
7. **The 17 Jay v4.2 test fixtures are sacred.** Any change to the pricing engine must keep all 17 within ±15%. Tests run in both repos.
8. **Workers (loaders/movers) are contractors.** No PAYE, no HMRC RTI. Just contractor invoicing.
9. **PII strictly stripped from Sentry/logs.** Names, emails, phones, full addresses never go to error tracking. Postcode districts are OK.
10. **Quote freeze.** Once a quote is issued, the price holds for `quote_validity_days`, regardless of pricing config changes.
11. **Job-centric domain.** `jobs` table is the spine. "Lead" = `jobs.stage='lead'`. Don't create a separate leads table.
12. **Vendor-neutral code.** Cloudflare-specific bindings live in adapter modules. The CRM core must be portable to Vercel if smoke test forces a switch.

---

## Stack pin (lock these versions)

```json
{
  "dependencies": {
    "next": "16.2.0",
    "react": "19.2.0",
    "react-dom": "19.2.0",
    "@supabase/supabase-js": "^2.99.0",
    "@supabase/ssr": "^0.9.0",
    "@opennextjs/cloudflare": "^1.0.0",
    "tailwindcss": "^4.0.0",
    "zod": "^3.23.0",
    "next-intl": "^3.20.0"
  }
}
```

Patch updates only (`^x.y.z`). Major/minor upgrades are deliberate decisions on a quiet day with full regression test.

---

## Open decisions (still to resolve before relevant phase)

These are flagged in the relevant phase docs. None blocks phase 00–04:

- **Phase 09:** Vehicle check form — keep public on painlessremovals.com or move to worker PWA only?
- **Phase 10:** Liveswitch scope — upload-only v1 or full live SDK integration?
- **Phase 11:** NPS review gating — final policy confirmation (Google ToS borderline).
- **Phase 13:** Tamar Telecom — Partner API access vs email parsing fallback.
- **Phase 17:** iMVE migration scope — full historical or active 12 months only? (Recommendation: 12mo active, rest archived as read-only.)
- **Phase 01 / general:** 2FA for admin from day 1 or post-1.0? (Recommendation: post-1.0.)
- **Phase 01 / general:** Session length — 30 days office / 7 days worker, or always 30?

---

## Costs (steady state)

| Item | Cost/month |
|------|------------|
| Supabase Pro | $25 |
| Cloudflare Workers Paid | already paid |
| Resend | $20 |
| Sentry | $26 |
| Anthropic API (Haiku duplicate detection) | ~$2 |
| WhatsApp Business API (Meta direct) | ~$10 (low volume) |
| **Total** | **~$83/mo** |

One-off: Tamar Partner API setup if approved (TBD), Liveswitch (already owned), GoCardless setup fee (£0, pay-as-you-go).

---

## What this spec is NOT

- It's not a working codebase. It's a build plan that Claude Code uses to write the codebase phase by phase.
- It's not a fixed-price contract with Jay. Phases will reveal unknowns and re-scoping is expected.
- It's not a SaaS spec. Multi-tenant infrastructure is in place day 1, but white-labelling for other UK removals companies is a phase 18+ project.
- It's not a competitor for full-fat enterprise CRM (Salesforce etc). It's deliberately Painless-shaped, with knobs that future tenants can re-tune.
